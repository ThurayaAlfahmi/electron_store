// Focus & Blus Events on Login Form
var emailField;
var passField;
var usernameHintTxt;
var passHintTxt;
var createAccForm;

function init() {
  emailField = document.getElementById("emailID");
  passField = document.getElementById("passwordID");
  emailHintTxt = document.getElementById("emailHintTxt");
  passHintTxt = document.getElementById("passHintText");
  focusedEmailElement(emailField, emailHintTxt);
  blurredElement(emailField, emailHintTxt);
  focusedPassElement(passField, passHintTxt);
  blurredElement(passField, passHintTxt);
}
function focusedEmailElement(inputField, txtField) {
  inputField.addEventListener(
    "focus",
    function () {
      txtField.innerHTML = "ex: name@gmail.com";
    },
    false
  );
}
function focusedPassElement(inputField, txtField) {
  inputField.addEventListener(
    "focus",
    function () {
      txtField.innerHTML = "ex: Rr@253142";
    },
    false
  );
}
function blurredElement(obj, txtField) {
  obj.addEventListener(
    "blur",
    function () {
      txtField.innerHTML = "";
    },
    false
  );
}

window.addEventListener("load", init, false);

function color(color) {
  document.forms[0].myInput.style.background = color;
}
