<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8" />
  <title>Create Account</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="styles.css" />
  <script src="FocusAndBlur.js"></script>
</head>

<body>
  <div class="navigation">
    <div class="container">
      <h3 style="color: white">
        <img src="assets/Logo.png" alt="Store Logo" style="vertical-align: middle" />
        Electron Store
      </h3>
      <div class="menu">
        <a href="index.html">Home</a>
        <a href="AudioVisuals.html">Audio Visuals</a>
        <a href="Laptops.html">Laptops</a>
        <a href="Monitors.html">Monitors</a>
      </div>
      <div class="left-icon">
        <a href="#">
          <img src="assets/Cart.png" alt="Cart Icon" />
        </a>
        <a href="login.php">
          <img src="assets/Profile.png" alt="Profile Icon" />
        </a>
      </div>
    </div>
  </div>
  <div style="margin-top: 120px;">
    <table style="margin: 0 auto;">
      <tr>
        <td>
          <p style="font-size: 50px;  text-align: center; "> Welcom to Electron Store</p>
        </td>
      <tr>
        <td>
          <img src="assets/login.png" />
        </td>

        <td>
          <form id="createAccForm" class="form-container" action="<?= $_SERVER['PHP_SELF'] ?>" method="post">

            <P style="text-align: center; font-weight: 700; font-size: larger; margin-bottom: 30px; margin-top: 10px;">
              Create Account</P>
            <label>First Name</label>
            <input type="text" id="Fname" name="Fname" required />
            <p id="fnameError"></p>

            <label>Last Name</label>
            <input type="text" id="Lname" name="Lname" required />
            <p id="lnameError"></p>

            <label>Email</label>
            <input type="text" id="createEmail" name="createEmail" required />
            <p id="emailError"></p>

            <label>Phone No.</label>
            <input type="text" id="phoneNum" name="phoneNum" required />
            <p id="phoneError"></p>

            <label>Password</label>
            <input type="password" id="pwd" name="pwd" required />
            <p id="passError"></p>

            <label>Confirm Password</label>
            <input type="password" id="confPassword" name="confPassword" required />
            <p id="conPassError"></p>

            <button type="submit" id="submitButton">SIGN UP</button>
            <div style="text-align: center;">
              <button type="reset" id="resetButton" class="clear-form">Clear Form</button>
            </div>

          </form>
        </td>
      </tr>
      </tr>
    </table>
  </div>
  <div class="footer">
    <a href="ContactUs.php"> Contact Us </a>
    <a href="AboutUs.html"> About Us </a>
    <p>
      “ Technology is not just a tool, it's a canvas for creativity and
      innovation “
    </p>
  </div>
</body>

<?php

$servername = "localhost";
$username = "root";
$password = "mysql";
$dbname = "electronstore";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
if (empty($_POST)) {
} else {

  $email = $_REQUEST["createEmail"];
  $phoneNum = $_REQUEST["phoneNum"];
  $password = $_REQUEST["pwd"];
  $confPass = $_REQUEST["confPassword"];
  $fname = $_REQUEST["Fname"];
  $lname = $_REQUEST["Lname"];
  checkData($conn, $email, $phoneNum, $password, $confPass, $fname, $lname);
}
function checkData($conn, $email, $phoneNum, $password, $confPass, $fname, $lname)
{

  $error = 1;
  // Remove all illegal characters from email
  $email = filter_var($email, FILTER_SANITIZE_EMAIL);


  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $error = -1;
    echo "<script>document.getElementById(\"emailError\").innerHTML = \"Not a valid email\";</script>";
  }


  if (!preg_match('/^[0-9]{10}+$/', $phoneNum)) {
    $error = -1;
    echo "<script>document.getElementById(\"phoneError\").innerHTML = \"Not a valid phone number\";</script>";
  }

  if (!preg_match("/^[a-zA-Z-' ]*$/", $fname)) {
    $error = -1;
    echo "<script>document.getElementById(\"fnameError\").innerHTML = \"First name should contains only letters\";</script>";
  }

  if (!preg_match("/^[a-zA-Z-' ]*$/", $lname)) {
    $error = -1;
    echo "<script>document.getElementById(\"lnameError\").innerHTML = \"Last name should contains only letters\";</script>";
  }

  $password_regex = "/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/";

  if (!preg_match($password_regex, $password)) {
    $error = -1;
    echo "<script>document.getElementById(\"passError\").innerHTML = \"Not a valid password\";</script>";
  }

  if ($confPass != $password) {
    $error = -1;
    echo "<script>document.getElementById(\"conPassError\").innerHTML = \"Password are not matching\";</script>";
  }

  if ($error == 1) {
    insertData($conn, $email, $phoneNum, $password, $fname, $lname);
  }
}

function insertData($conn, $email, $phoneNum, $password, $fname, $lname)
{
  //Insert data into users table
  $sql = "INSERT INTO users (fname, lname, phone_num, email, pwd)
    VALUES ('$fname', '$lname', '$phoneNum', '$email', '$password')";

  if ($conn->query($sql) === TRUE) {
    header("Location: login.php");
    exit;
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
  $conn->close();
}
?>

</html>

<script>
  var createAccForm = document.getElementById("createAccForm");
  createAccForm.addEventListener("submit", function () { return confirm("Are you sure to proceed ? "), false });
  createAccForm.addEventListener("reset", function () { return confirm("Are you sure to clear the form ? "), false });
</script>