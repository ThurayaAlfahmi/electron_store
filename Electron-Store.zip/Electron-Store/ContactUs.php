<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Electron Store</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="styles.css" />
</head>

<body>
    <div class="navigation">
        <div class="container">
            <h3 style="color: white">
                <img src="assets/Logo.png" alt="Store Logo" style="vertical-align: middle" />
                Electron Store
            </h3>
            <div class="menu">
                <a href="index.html">Home</a>
                <a href="AudioVisuals.html">Audio Visuals</a>
                <a href="Laptops.html">Laptops</a>
                <a href="Monitors.html">Monitors</a>
            </div>
            <div class="left-icon">
                <a href="Cart.html">
                    <img src="assets/Cart.png" alt="Cart Icon" />
                </a>
                <a href="login.php">
                    <img src="assets/Profile.png" alt="Profile Icon" />
                </a>
            </div>
        </div>
    </div>

    <div class="footer">
        <a href="ContactUs.php"> Contact Us </a>
        <a href="AboutUs.html"> About Us </a>
        <p>
            “ Technology is not just a tool, it's a canvas for creativity and
            innovation “
        </p>
    </div>

    <div class="contact-us">
        <div class="contact-section1">
            <div class="section1-header">
                <h2>Contanct Information</h2>
                <p>Fill up the form and our team will get back to you within 24 hours.</p>
            </div>
            <div class="contact-info">
                <div class="contact-phone">
                    <img src="assets/Contact Us/telephone.png" alt="telephone">
                    <p>9200 00089</p>
                </div>
                <div class="contact-email">
                    <img src="assets/Contact Us/email.png" alt="email">
                    <a href="mailto:Electron-contact@Electron.com">Electron-contact@Electron.com</a></p>
                </div>
                <div class="contact-location">
                    <img src="assets/Contact Us/location-pin.png" alt="location">
                    <p>Jeddah</p>
                </div>
                <div class="social-media">
                    <a href="https://www.twitter.com/">
                        <img src="assets/Contact Us/twitter.png" alt="twitter" />
                    </a>
                    <a href="https://www.instagram.com/">
                        <img src="assets/Contact Us/instagram.png" alt="instagram" />
                    </a>
                </div>
            </div>
        </div>
        <div class="contact-section2">
            <form id="contactForm" action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
                <div class="contact-form">
                    <h1>Contact Us</h1>
                    <h3>General info</h3>
                    <div class="contact-us-input">
                        <div class="fname">
                            <label for="fname" class="fname-label">First Name</label>
                            <input type="text" id="fname" name="fname" required>
                            <p id="fnameCError"></p>
                        </div>
                        <div class="lname">
                            <label for="lname">Last Name</label>
                            <input type="text" id="lname" name="lname" required>
                            <p id="lnameCError"></p>
                        </div>
                        <div class="email">
                            <label for="email">Email</label>
                            <input type="text" id="email" name="email" required>
                            <p id="emailCError"></p>
                        </div>
                        <div class="phone-num">
                            <label for="phone-num">Phone Number</label>
                            <input type="text" id="phone-num" name="phone-num" required>
                            <p id="phoneCError"></p>
                        </div>
                    </div>
                    <h3>What is the reason for contacting us ?</h3>
                    <p id="reasonError"></p>
                    <div class="contact-reason">
                        <span>
                            <input type="radio" id="complain" name="contact-reason" value="complain" required>
                            <label for="complain">Complain</label>
                        </span>
                        <span>
                            <input type="radio" id="suggest" name="contact-reason" value="suggest" required>
                            <label for="suggest">Suggest</label>
                        </span>
                        <span>
                            <input type="radio" id="other" name="contact-reason" value="other" required>
                            <label for="other">Other</label>
                        </span>
                    </div>
                    <div class="message">
                        <h3>Message</h3>
                        <p id="msgError"></p>
                        <textarea id="message" name="message" rows="8" cols="50"
                            placeholder="Write your message here..." required></textarea>
                    </div>
                    <div class="submit">
                        <input type="submit" value="Send">
                        <button type="reset" id="resetButton" class="clear-formC">Clear Form</button>
                    </div>
                </div>
            </form>
        </div>


</body>


<?php

if (empty($_POST)) {
} else {

    $email = $_REQUEST["email"];
    $phoneNum = $_REQUEST["phone-num"];
    $fname = $_REQUEST["fname"];
    $lname = $_REQUEST["lname"];
    $reason = $_REQUEST["contact-reason"];
    $msg = $_REQUEST["message"];

    checkData($email, $phoneNum, $fname, $lname, $reason, $msg);
}
function checkData($email, $phoneNum, $fname, $lname, $reason, $msg)
{

    // Remove all illegal characters from email
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);


    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>document.getElementById(\"emailCError\").innerHTML = \"Not a valid email\";</script>";
    }


    if (!preg_match('/^[0-9]{10}+$/', $phoneNum)) {
        echo "<script>document.getElementById(\"phoneCError\").innerHTML = \"Not a valid phone number\";</script>";
    }

    if (!preg_match("/^[a-zA-Z-' ]*$/", $fname)) {
        echo "<script>document.getElementById(\"fnameCError\").innerHTML = \"First name should contains only letters\";</script>";
    }

    if (!preg_match("/^[a-zA-Z-' ]*$/", $lname)) {
        echo "<script>document.getElementById(\"lnameCError\").innerHTML = \"Last name should contains only letters\";</script>";
    }

    if ($reason == "") {
        echo "<script>document.getElementById(\"reason\").innerHTML = \"Choose a reason\";</script>";
    }

    if ($msg == "") {
        echo "<script>document.getElementById(\"message\").innerHTML = \"Please write a message\";</script>";
    }
}

?>


<script>
    var createAccForm = document.getElementById("contactForm");
    createAccForm.addEventListener("submit", function () { return confirm("Are you sure to proceed ? "), false });
    createAccForm.addEventListener("reset", function () { return confirm("Are you sure to clear the form ? "), false });
</script>

</html>