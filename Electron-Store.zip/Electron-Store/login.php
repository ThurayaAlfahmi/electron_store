<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8" />
  <title>Login Page</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="styles.css" />
  <script src="FocusAndBlur.js"></script>
</head>

<body>
  <div class="navigation">
    <div class="container">
      <h3 style="color: white">
        <img src="assets/Logo.png" alt="Store Logo" style="vertical-align: middle" />
        Electron Store
      </h3>
      <div class="menu">
        <a href="index.html">Home</a>
        <a href="AudioVisuals.html">Audio Visuals</a>
        <a href="Laptops.html">Laptops</a>
        <a href="Monitors.html">Monitors</a>
      </div>
      <div class="left-icon">
        <a href="Cart.html">
          <img src="assets/Cart.png" alt="Cart Icon" />
        </a>
        <a href="login.php">
          <img src="assets/Profile.png" alt="Profile Icon" />
        </a>
      </div>
    </div>
  </div>
  <div style="margin-top: 120px;">
    <table style="margin: 0 auto;">
      <tr>
        <td>
          <p style="font-size: 50px;  text-align: center; "> Welcom to Electron Store</p>
        </td>
      <tr>
        <td>
          <img src="assets/HappyGirl.png" width="700" />
        </td>
        <td>
          <form name="loginForm" class="form-container" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>"
            method="POST">

            <P style="text-align: center; font-weight: 700; font-size: larger; margin-bottom: 30px; margin-top: 10px;">
              Login to your account</P>

            <p id="emailHintTxt"></p>
            <input type="text" onkeydown="color('yellow')" onkeyup="color('white')" name="myInput" id="emailID"
              placeholder="Email" />

            <p id="passHintText"></p>
            <input type="password" id="passwordID" name="passwordName" placeholder="Password" />

            <button type="submit">LOGIN</button>

            <p style="margin-top: 25px;">
              Don't have an account?
              <a href="CreateAccount.php">Sign up</a>
            </p>
          </form>
        </td>
      </tr>
      </tr>
    </table>
  </div>

  <div class="footer">
    <a href="ContactUs.php">Contact Us</a>
    <a href="AboutUs.html">About Us</a>
    <p>
      “ Technology is not just a tool, it's a canvas for creativity and
      innovation “
    </p>
  </div>
</body>
<?php
if (!empty($_POST)) {
  $servername = "localhost";
  $username = "root";
  $password = "mysql";
  $dbname = "electronstore";

  // Create connection
  $conn = new mysqli($servername, $username, $password, $dbname);
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  // Retrieve data from users table
  $email = $_REQUEST["myInput"];
  $password = $_REQUEST["passwordName"];

  $sql = "SELECT * FROM users WHERE email = '$email' AND pwd = '$password'";
  $result = $conn->query($sql);


  if (mysqli_num_rows($result) > 0) {
    // User found, redirect to a home page
    header("Location: index.html");
    exit;
  } else {
    // User not found, display an error message
    echo "<script>alert(\"Email or password are incorrect\");</script>";
  }
  $conn->close();
}
?>

</html>